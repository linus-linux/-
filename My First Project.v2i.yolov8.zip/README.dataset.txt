# My First Project > 2025-07-15 7:39pm
https://universe.roboflow.com/yolov10-lhcdf/my-first-project-qklm8

Provided by a Roboflow user
License: CC BY 4.0

